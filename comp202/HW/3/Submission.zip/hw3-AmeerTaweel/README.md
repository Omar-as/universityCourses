# COMP202 - HW#3

Wrote a program that uses DFS to help Mr. Mole get the maximum amout of
potatoes.

Wrote extra more complicated test to assert correctness.

All tests are passing.
