package crashtable;

import java.util.ArrayList;

public class CrashTable {
	private static class EntryNode {
		private final String    key;
		private       Object    value;
		private       EntryNode next;

		private EntryNode(String key, Object value) {
			this.key   = key;
			this.value = value;
		}
	}

	private static final int INITIAL_SIZE  = 8;
	private static final int RESIZE_FACTOR = 2;
	private static final int MAX_CONFLICTS = 10;

	private EntryNode[] table = new EntryNode[INITIAL_SIZE];

	public Object get(String key) {
		int hash = this.hash(key);
		var node = this.table[hash];

		while (node != null) {
			if (node.key.equals(key)) {
				return node.value;
			}

			node = node.next;
		}

		return null;
	}

	public Object get(String key, Object def) {
		var value = this.get(key);
		return value != null ? value : def;
	}

	public Object put(String key, Object value) {
		int hash = this.hash(key);
		var node = this.table[hash];

		// If there is no bucket
		if (node == null) {
			return this.table[hash] = new EntryNode(key, value);
		}

		// Starting from 1 because head
		int entries = 1;

		while (node.next != null) {
			entries++;

			if (node.key.equals(key)) {
				var old = node.value;
				node.value = value;

				return old;
			}

			node = node.next;
		}

		node.next = new EntryNode(key, value);

		if (entries > MAX_CONFLICTS) {
			resize(this.table.length * RESIZE_FACTOR);
		}

		return null;
	}

	public Object remove(String key) {
		int hash = this.hash(key);
		var node = this.table[hash];

		// Special case if the bucket does not exist
		if (node == null) {
			return null;
		}

		if (node.key.equals(key)) {
			this.table[hash] = node.next;
			return node.value;
		}

		node = node.next;

		while (node.next != null) {
			if (node.next.key.equals(key)) {
				var old = node.next.value;
				node.next = node.next.next;

				return old;
			}

			node = node.next;
		}

		return null;
	}

	public String[] getKeys() {
		var keys = new ArrayList<String>();

		for (var node : this.table) {
			while (node != null) {
				keys.add(node.key);
				node = node.next;
			}
		}

		return keys.toArray(new String[0]);
	}

	public void resize(int size) {
		EntryNode[] oldTable = this.table;
		this.table = new EntryNode[size];

		for (var node : oldTable) {
			while (node != null) {
				this.put(node.key, node.value);
				node = node.next;
			}
		}
	}

	private int hash(String key) {
		int a = 'a';
		int p = 89;
		int m = this.table.length;

		int pPow      = 1;
		int hashValue = 0;

		for (int c : key.toCharArray()) {
			hashValue = (hashValue + (c - a + 1) * pPow) % m;
			pPow      = (pPow * p) % m;
		}

		return Math.abs(hashValue);
	}
}
