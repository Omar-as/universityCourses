import crashtable.CrashTable;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Main {

	public static void main(String[] args) throws IOException {

		// The format is [["Key", "Value"]]
		List<String[]> list = new ArrayList<>();

		// Table path argument provided
		if (args.length > 0) {
			list = Files.lines(Path.of(args[0].trim()))
					.map(l -> l.split("\\s+=>\\s+"))
					.collect(Collectors.toList());
		}

		var table = new CrashTable();

		for (var l : list) {
			table.put(l[0], l[1]);
		}

		System.out.println("Inserted " + table.getKeys().length + " entries");
	}
}
