https://www.youtube.com/watch?v=K9qMm3JbOH0&list=FL2IRZUBz-hkdKGmWwLwlyfw&index=2
I have used this as a guide to my code

My code has three classes : Main, Game, Button.

Main: This class is the main class and i just made an instance of button class in it and called it.

Button: This class is where i created my frame, panels, labels, pause/play button, reset button.

Game: This class is where i created the game mechanics in it. I have a constructor, paint method, actionPerformed, and KeyPressed.
The actionPerformed is where my game checks all intersections with ball.
The KeyPressed is where it checks if left or right is pressed.

Sometimes when you run the code it does not show all the components so just close and run it again this is due to eclipse being bad.