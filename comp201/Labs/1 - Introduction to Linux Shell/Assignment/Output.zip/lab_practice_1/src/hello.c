#include <stdio.h> 
  
int main(void)
{
    printf("Welcome to the COMP201 Fall 2021\n");
    return 0;
}
