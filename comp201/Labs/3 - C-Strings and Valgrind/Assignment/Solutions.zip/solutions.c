#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>


char *strlwr(char *str)
{
    unsigned char *p = (unsigned char *)str;

    while (*p)
    {
        *p = tolower((unsigned char)*p);
        p++;
    }

    return str;
}


//5pts
/*
 * checks if the contents of string str1 and str2 are equal
 * Use strcmp() function to compare
 * return 1 if equal. Else 0.
 * YOU MAY USE ANY STRING FUNCTION
 */
int equalStr(char str1[], char str2[]){
	
	if (strcmp(str1, str2) == 0){
		return 1;
	}
	return 0;
}


//10 pts
/*
 * DO NOT USE any string functions
 * You can only use strlen()
 * replace first n characters of str1[] with '*'
 * string length will be > n
 * Example: occludeStr("Efehan", 3) = "***han"
 */
char* occludeStr(char str1[], int n)
{
  	int i;
  	for (i = 0; i < n; i++) {
        str1[i] = '*';
    }
    return str1;
	
}  //NOTE: If you create a local variable and return it, it won't work; because that var will not exist outside the function. 
   //Also, here you cannot use strcmp, it is a string function, prohibited in the description.

//10 pts
/*
 * find the substring "key" in str
 * DO NOT USE any string functions 
 * You can only use strlen()
 * returns the index of "k" of substring "key"
 * returns -1 if not found
 * For example: findKey("this key") == 5;
 * For example: findKey("hello world") == -1;
 */
int findKey(char str[])
{
	int index = 0;
	//Character by Character approach
	while(str[index] != '\0') {
		if (str[index] == 'k'){
			if (str[index+1] == 'e'){
				if (str[index+2] == 'y'){
					return index;
				}
			}
    } 
		index++;
	}
	return -1;
	
}

//25 pts
/* Find number of occurrences of word str1 in the sentence str2 (not case sensitive)
 * Returns 0 if not found
 * For Example: numOccur( "WE", "We few, we happy few, we band of brothers") = 3
 * YOU MAY USE ANY STRING FUNCTION
 */
int numOccur(char str1[] ,char str2[])
{
	int i, j, found, count;
    int stringLen, searchLen;

	str1 = strlwr(str1);   //set all to lowercase to do not case sensitive searching
	str2 = strlwr(str2);

    stringLen = strlen(str2);      // length of string
    searchLen = strlen(str1);      // length of word to be searched

    count = 0;

    for(i=0; i <= stringLen-searchLen; i++)
    {
        /* Match word with string */
        found = 1;
        for(j=0; j<searchLen; j++)
        {
            if(str2[i + j] != str1[j])   //if substr do not match, set found to 0 and continue searching
            {
                found = 0;
                break;
            }
        }

        if(found == 1) 		//if found, increment the count
        {
            count++;
        }
    }
    return count;
	
}

//20pts
/* Find the max occuring char in str (case sensitive)
 * For Example: maxOccurChar("We few, we happy few, we band of brothers") = 'e'
 * Do not count whitespaces.
 * DO NOT USE any string functions
 * You can only use strlen()
 */
char maxOccurChar(char str[])
{
	char result;
  	int i, len;
  	int max = -1;
  	
  	int freq[256] = {0}; //an array containing all possible 256 chars
  	
  	len = strlen(str);
  	
  	for(i = 0; i < len; i++)
  	{
		if(freq[str[i]] != '\t') //if it is a whitespace ignore it
		{
  			freq[str[i]]++;
		}
	}
  		
  	for(i = 0; i < len; i++)
  	{
		if(max < freq[str[i]]) //if frequency is larger than max found so far set the max and result
		{
			max = freq[str[i]];
			result = str[i];
		}
	}

	return result;
	
}

//30pts

/* Implement the atoi function in the standart C library
 * Atoi Function: Given a string as an input it returns corresponding integer number
 * Note: Ignore whitespace characters.
 * Attention: Check sign bits, if the number starts with a '+' treat it as positive, if it is '-' treat it as negative. If there is no sign it is positive.
 * If the number starts with a char other then whitespace or a number return 0.
 * If a char other than a number or a whitespace is encountered end the algorithm and return the number you have found up to that point. 
 * Return 0 if a string representation cannot be formulated.
 * For Example: atoiF("+278") = 278
 * For Example: atoiF("   -15") = -15
 * For Example: atoiF("278 with words") = 278
 * For Example: atoiF("Words and -900") = 0
 * YOU MAY USE ANY STRING FUNCTION (other than atoi of course).
 * Note: We will not test against overflows you can ignore them.
 */
int atoiF(char str1[])
{
	int sign = 1; 
	char* p = str1;
	while(*p == ' ') p++;  //ignore whitespaces
	if(*p == '-'){    //if there is '-' it is negative, flip the sign
    	p++;
    	sign = -1;
	}
	else if(*p == '+') p++; //if there is a plus sign continue

	if(*p == '\0' || *p < '0' || *p > '9') return 0; //there is no number at the beginning


	int res = (*p++ - '0') * sign;   //init for first number to come
	while(*p != '\0' && *p >= '0' && *p <= '9'){ 	//continue as long as it is not the end of string and chars are numbers
    
    	res = res * 10 + sign * (*p - '0');  //add for coming numbers
    	p++;    //advance the string of numbers until a char which is not a Number or space is found
}
return res;
}


int main() 
{
	int score = 0;

	char str5[] = "radar\0";
	char str6[] = "radar\0";
	char str7[] = "joke\0";
	char str8[] = "joker\0";
	char str9[] = "Efehan\0";
	char str10[] = "Hello World\0";

	char str11[] = "leads";
	char str12[] = "Fear leads to anger anger leads to hatred hatred leads to conflict conflict leads to suffering";
	char str13[] = "Leads";
	char str14[] = "Fear LEADS to anger anger Leads to hatred hatred leadS to conflict conflict leads to suffering";
	char str15[] = "possible";
	char str16[] = "This is impossible";
	char str17[] = "pasta";
  	
	if (equalStr(str5, str6)==1 && equalStr(str7, str8)==0){
		printf("equalStr test passed!\n");
		score +=5;
	}
	else{
		printf("equalStr test failed!\n");
	}
	
	
	if (findKey("ketchup recipe\0") == -1){
		printf("findKey test1 passed!\n");
		score +=5;
	}
	else{
		printf("findKey test1 failed!\n");
	}

	if (findKey("Did you find the key\0") == 17){
		printf("findKey test2 passed!\n");
		score +=5;
	}
	else{
		printf("findKey test2 failed!\n");
	}
	

	if (strcmp(occludeStr(str9, 3), "***han") == 0)
	{

		printf("occludeStr test1 passed!\n");
		score +=5;
	}
	else{
		printf("occludeStr test1 failed!\n");
	}

	if (strcmp(occludeStr(str10, 5), "***** World") == 0)
	{

		printf("occludeStr test2 passed!\n");
		score +=5;
	}
	else{
		printf("occludeStr test2 failed!\n");
	}

	if (numOccur(str11, str12) == 4)
	{
		printf("numOccur test1 passed!\n");
		score +=10;
	}
	else{
		printf("numOccur test1 failed!\n");
	}

	if (numOccur(str13, str14) == 4)
	{
		printf("numOccur test2 passed!\n");
		score +=10;
	}
	else{
		printf("numOccur test2 failed!\n");
	}

	if (numOccur(str17, str14) == 0)
	{
		printf("numOccur test3 passed!\n");
		score +=5;
	}
	else{
		printf("numOccur test3 failed!\n");
	}

	if(maxOccurChar("Fear leads to anger anger leads to hatred hatred leads to conflict conflict leads to suffering") == 'e')
	{
		printf("maxOccur test passed!\n");
		score +=20;
	}
	else
	{
		printf("maxOccur test failed!\n");
	}
	
	if(atoi("   +5976") == atoiF("   +5976"))

	{
		printf("atoiF test1 passed!\n");
		score +=5;
	}
	else
	{
		printf("atoiF test1 failed!\n");
	}

	if(atoi("-5812with words") == atoiF("-5812with words"))

	{
		printf("atoiF test2 passed!\n");
		score +=5;
	}
	else
	{
		printf("atoiF test2 failed!\n");
	}

	if(atoi("Words 98") == atoiF("Words 98"))

	{
		printf("atoiF test3 passed!\n");
		score +=5;
	}
	else
	{
		printf("atoiF test3 failed!\n");
	}

	if(atoi("25") == atoiF("25"))

	{
		printf("atoiF test4 passed!\n");
		score +=5;
	}
	else
	{
		printf("atoiF test4 failed!\n");
	}

	if(atoi("-53E85") == atoiF("-53E85"))

	{
		printf("atoiF test5 passed!\n");
		score +=5;
	}
	else
	{
		printf("atoiF test5 failed!\n");
	}

	if(atoi("   -2F3") == atoiF("   -2F3"))

	{
		printf("atoiF test6 passed!\n");
		score +=5;
	}
	else
	{
		printf("atoiF test6 failed!\n");
	}
  
	printf("This user's score is: %d\n",score);
	

	return 0;
}