#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>

char *lowerCase(char *str)  //Convert a string to lowercase without using strlwr() and return it
{
    
}

void concat(char *str1, char *str2) //concatenate two strings and print it
{
    
}



char *RemoveDup(char *pString)  //Remove duplicate characters from pString
{
    
}

void largestSmallest(char *pString) //Find the largest and smallest word in a String
{

}

bool areAnagram(char *str1, char *str2) //return true if given two strings are anagram of each other

{

}

int main(int argc, char *argv[])
{
    if (strcmp(argv[1], "removeDup") == 0)
    {
        char pString[100];
        printf("Enter a string:\n");
        scanf("%[^\n]s", pString);
        char *pResultString = RemoveDup(pString); //Remove duplicate
        printf("%s\n", pResultString);            //print result string
    }

    else if (strcmp(argv[1], "largestSmallest") == 0)
    {
        char pString[100];
        printf("Enter a string:\n");
        scanf("%[^\n]s", pString);
        largestSmallest(pString);
    }

    else if (strcmp(argv[1], "lowerCase") == 0)
    {
        char pString[100];
        printf("Enter a string:\n");
        scanf("%[^\n]s", pString);
        char *pResultString = lowerCase(pString);
        printf("%s\n", pResultString); //print result string
    }

    else if (strcmp(argv[1], "concat") == 0)
    {
        char pString1[100], pString2[100];
        printf("Enter the first string:\n");
        fgets(pString1, sizeof(pString1), stdin);
        printf("Enter the second string:\n");
        fgets(pString2, sizeof(pString2), stdin);
        concat(pString1, pString2);
    }

    else if (strcmp(argv[1], "areAnagram") == 0)
    {
        char pString1[100], pString2[100];
        printf("Enter the first string:\n");
        fgets(pString1, sizeof(pString1), stdin);
        printf("Enter the second string:\n");
        fgets(pString2, sizeof(pString2), stdin);
        if(areAnagram(pString1, pString2))
        {
            printf("The two strings are anagram of each other.\n");
        }
        else
        {
            printf("The two strings are not anagram of each other.\n");
        }
    }
    else
    {
        printf("Wrong Function!\n");
    }
}