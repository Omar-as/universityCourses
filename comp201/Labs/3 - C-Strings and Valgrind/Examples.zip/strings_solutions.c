#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>

char *lowerCase(char *str) //Convert a string to lowercase without using strlwr() and return it
{
    unsigned char *p = (unsigned char *)str;

    while (*p)
    {
        *p = tolower((unsigned char)*p);
        p++;
    }

    return str;
}

void concat(char *str1, char *str2) //concatenate two strings and print it
{
    char i, j, l, m, k;

    l = strlen(str1);
    m = strlen(str2);
    for (i = 0; i < l - 1; ++i)
        ;          /* value i contains reaches the end of string str1. */
    str1[i] = ' '; /* add a space with string str1. */
    i++;           /* value i increase by 1 for the blank space */

    for (j = 0; j < m - 1; ++j, ++i)
    {
        str1[i] = str2[j];
    }
    k = strlen(str1);
    str1[k] = 0;

    printf("After concatenation the string is : \n ");
    printf("%s", str1);
    printf("\n\n");
}



#define SIZE_BIN_TABLE 256
#define UNIQUE_CHARACTER 0
#define MARK_USED 1

char *RemoveDup(char *pString) //Remove duplicate characters from pString and return it
{
    short binTable[SIZE_BIN_TABLE] = {0}; //Bin table
    int startIndex = 0, resultIndex = 0;  // Index
    unsigned char binTableIndex = 0;
    while (*(pString + startIndex)) //Till not get null character
    {
        binTableIndex = *(pString + startIndex);         //get character from startIndex
        if (binTable[binTableIndex] == UNIQUE_CHARACTER) //check unique character
        {
            binTable[binTableIndex] = MARK_USED;                //Marked the binTableIndex
            *(pString + resultIndex) = *(pString + startIndex); //copy character in result string
            resultIndex++;
        }
        startIndex++;
    }
    *(pString + resultIndex) = '\0'; //Assign null character to remove extra character
    return pString;
}

void largestSmallest(char *str) //Find the largest and smallest word in str and print them
{
    char word[20], mx[20], mn[20];
    int i = 0, j = 0, flg = 0;
    for (i = 0; i < strlen(str); i++)
    {
        while (i < strlen(str) && !isspace(str[i]) && isalnum(str[i])) //until the end of the word
        {
            word[j++] = str[i++];
        }
        if (j != 0)
        {
            word[j] = '\0';
            if (!flg) //if it is the first word set it to both min and max
            {
                flg = !flg;
                strcpy(mx, word);
                strcpy(mn, word);
            }
            if (strlen(word) > strlen(mx)) //if it is larger than max it is max
            {
                strcpy(mx, word);
            }
            if (strlen(word) < strlen(mn)) //if it is larger than min it is min
            {
                strcpy(mn, word);
            }
            j = 0;
        }
    }
    printf("The largest word is '%s' \nand the smallest word is '%s' \nin the string : '%s'.\n", mx, mn, str);
}


#define NO_OF_CHARS 256

bool areAnagram(char *str1, char *str2) //return true if given two strings are anagram of each other

{

    int count1[NO_OF_CHARS] = {0};
    int count2[NO_OF_CHARS] = {0};
    int i;

    // For each character in input strings, increment count
    // in the corresponding count array
    for (i = 0; str1[i] && str2[i]; i++)
    {
        count1[str1[i]]++;
        count2[str2[i]]++;
    }

    // If both strings are of different length. Removing
    // this condition will make the program fail for strings
    // like "aaca" and "aca"
    if (str1[i] || str2[i])
        return false;

    // Compare count arrays
    for (i = 0; i < NO_OF_CHARS; i++)
        if (count1[i] != count2[i])
            return false;

    return true;
}

int main(int argc, char *argv[])
{
    if (strcmp(argv[1], "removeDup") == 0)
    {
        char pString[100];
        printf("Enter a string:\n");
        scanf("%[^\n]s", pString);
        char *pResultString = RemoveDup(pString); //Remove duplicate
        printf("%s\n", pResultString);            //print result string
    }

    else if (strcmp(argv[1], "largestSmallest") == 0)
    {
        char pString[100];
        printf("Enter a string:\n");
        scanf("%[^\n]s", pString);
        largestSmallest(pString);
    }

    else if (strcmp(argv[1], "lowerCase") == 0)
    {
        char pString[100];
        printf("Enter a string:\n");
        scanf("%[^\n]s", pString);
        char *pResultString = lowerCase(pString);
        printf("%s\n", pResultString); //print result string
    }

    else if (strcmp(argv[1], "concat") == 0)
    {
        char pString1[100], pString2[100];
        printf("Enter the first string:\n");
        fgets(pString1, sizeof(pString1), stdin);
        printf("Enter the second string:\n");
        fgets(pString2, sizeof(pString2), stdin);
        concat(pString1, pString2);
    }

    else if (strcmp(argv[1], "areAnagram") == 0)
    {
        char pString1[100], pString2[100];
        printf("Enter the first string:\n");
        fgets(pString1, sizeof(pString1), stdin);
        printf("Enter the second string:\n");
        fgets(pString2, sizeof(pString2), stdin);
        if(areAnagram(pString1, pString2))
        {
            printf("The two strings are anagram of each other.\n");
        }
        else
        {
            printf("The two strings are not anagram of each other.\n");
        }
    }
    else
    {
        printf("Wrong Function!\n");
    }
}