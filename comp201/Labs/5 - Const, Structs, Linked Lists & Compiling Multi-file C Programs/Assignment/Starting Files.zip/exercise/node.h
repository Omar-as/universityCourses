
typedef struct Node
{
    int content;
    struct Node* next;
} Node;
