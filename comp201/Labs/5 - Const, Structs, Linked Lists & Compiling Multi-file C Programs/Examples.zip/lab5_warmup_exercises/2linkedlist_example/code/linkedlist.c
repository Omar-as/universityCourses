#include "linkedlist.h"
#include "stdlib.h"


void LinkedList_init(LinkedList* l){
    // Initializes the LinkedList
    l->root = NULL; // initialize root node to NULL
} 

int LinkedList_length(LinkedList* l){
    // Calculates the length of the LinkedList
    
    // FILL HERE 
    // IDEA: count while looping through nodes until node.next == NULL
    // See insert function below.
    
    return 0;
}

int LinkedList_remove(LinkedList* l){
    // Deletes the last node and returns its value (content)
    // Note: return -1 when there is no value in the list.
    
    // FILL HERE 
    // NOTE: DO NOT FORGET TO FREE THE DYNAMICAL MEMORY USED FOR THE DELETED NODE
    // See insert function below.
    
    return 0;
}

void LinkedList_insert(LinkedList* l, int value){
    // Appends the value to the end of linked list as a new node
    Node* n = malloc(sizeof(Node)); // create a new node
    n->content = value;
    n->next = NULL;

    if(l->root == NULL){
        l->root = n;
    }else{
        // Iterating through nodes until last node
        Node* current = l->root;
        while(current->next != NULL){
            current = current->next;
        }
        current->next = n;
    }
}
 

