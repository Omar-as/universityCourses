#include "stdio.h"
#include "stdlib.h"
#include "linkedlist.h"

int main(int argc, char const *argv[])
{
    LinkedList l;
    LinkedList_init(&l);
    LinkedList_insert(&l, 1);
    LinkedList_insert(&l, 2);
    LinkedList_insert(&l, 3);
    
    if(LinkedList_length(&l) == 3){
        printf("LinkedList: length function WORKS!\n");
    }else{
        printf("LinkedList: length function FAILS!\n");
    }

    int v1 = LinkedList_remove(&l);
    int v2 = LinkedList_remove(&l);
 
    if(v1 == 3 && v2 == 2){
        printf("LinkedList: remove function WORKS!\n");
    }else{
        printf("LinkedList: remove function FAILS!\n");
    }

    return 0;
}
