#include "linkedlist.h"
#include "stdlib.h"


void LinkedList_init(LinkedList* l){
    // Initializes the LinkedList
    l->root = NULL; // initialize root node to NULL
} 

int LinkedList_length(LinkedList* l){
    // Calculates the length of the LinkedList
    
    // FILL HERE 
    // IDEA: count while looping through nodes until node.next == NULL
    // See insert function below.
    
    if(l->root == NULL){
        return 0;
    }else{
        int count = 1;
        Node* current = l->root;
        while(current->next != NULL){
            current = current->next;
            count++;
        }
        return count;
    }
}

int LinkedList_remove(LinkedList* l){
    // Deletes the last node and returns its value (content)
    // Note: return -1 when there is no value in the list.
    
    // FILL HERE 
    // NOTE: DO NOT FORGET TO FREE THE DYNAMICAL MEMORY USED FOR THE DELETED NODE
    // See insert function below.

    int value = -1;
    if(l->root == NULL){
        return value;
    }else if(l->root->next == NULL){
        // when there is only root node
        value = l->root->content;
        free(l->root);
        l->root = NULL;
        return value;
    }else{
        // when there multiple nodes
        Node* current = l->root;
        while(current->next->next != NULL){
            current = current->next;
        }
        value = current->next->content;
        free(current->next);
        current->next = NULL;
        return value;
    }
}

void LinkedList_insert(LinkedList* l, int value){
    // Appends the value to the end of linked list as a new node
    Node* n = malloc(sizeof(Node)); // create a new node
    n->content = value;
    n->next = NULL;

    if(l->root == NULL){
        l->root = n;
    }else{
        // Iterating through nodes until last node
        Node* current = l->root;
        while(current->next != NULL){
            current = current->next;
        }
        current->next = n;
    }
}
 

