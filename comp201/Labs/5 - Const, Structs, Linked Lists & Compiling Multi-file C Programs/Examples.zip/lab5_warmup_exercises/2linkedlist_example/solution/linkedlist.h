#include "node.h"

typedef struct LinkedList
{
    Node* root; // the first node of the linked list
    // This struct can store more variables depending on the application but we kept it simple.
} LinkedList;

// FUNCTIONS: see linkedlist.c for the implementations of the push function and implement the length and pop functions there.

void LinkedList_init(LinkedList* l); // Initializes the LinkedList

int LinkedList_length(LinkedList* l); // Calculates the length of the LinkedList

int LinkedList_remove(LinkedList* l); // Deletes the last node and returns its value (content)

void LinkedList_insert(LinkedList* l, int value); // Appends the value to the end of linked list as a new node
