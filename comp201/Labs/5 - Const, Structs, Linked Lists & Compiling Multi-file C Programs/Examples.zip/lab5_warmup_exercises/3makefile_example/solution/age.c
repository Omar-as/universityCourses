#include "age.h"

int calculate_age(int birth_year){
    return 2020-birth_year;
}