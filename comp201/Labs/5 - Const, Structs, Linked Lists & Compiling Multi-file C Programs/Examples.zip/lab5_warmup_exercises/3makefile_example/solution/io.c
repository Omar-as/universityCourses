#include "io.h"
#include "stdio.h"

int ask_birth_year(){
    int birth_year;
    printf("Please enter your birth year: ");
    scanf("%d", &birth_year);
    return birth_year;
}

void print_age(int age){
    printf("Your age is %d!\n", age);
}