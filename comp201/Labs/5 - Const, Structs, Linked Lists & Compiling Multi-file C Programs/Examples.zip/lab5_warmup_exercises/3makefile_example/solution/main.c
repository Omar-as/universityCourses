#include "age.h"
#include "io.h"

int main(int argc, char const *argv[])
{
    int birth_year = ask_birth_year();
    int age = calculate_age(birth_year);
    print_age(age);
    return 0;
}
