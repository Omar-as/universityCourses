int ask_birth_year();
void print_age(int age);