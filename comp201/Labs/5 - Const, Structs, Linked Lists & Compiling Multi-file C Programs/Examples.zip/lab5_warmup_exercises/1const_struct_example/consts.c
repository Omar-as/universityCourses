#include<stdio.h>

const char* YOUR_ANSWER = "YOUR ANSWER";
char* YES = "YES";
char NO[10] = "NO";
int j = 3;

struct coordinates2d{
    int x;
    const int y;
};

int main(int argc, char const *argv[])
{   
    // PLEASE ANSWER THE FOLLOWING YES/NO QUESTIONS GIVEN IN printf STATEMENTS. 
    // THEN, YOU CAN COMPARE YOUR ANSWERS WITH THE SOLUTIONS in the consts_solution.c
    const int i = 10;
    struct coordinates2d A = {i, j};
    const struct coordinates2d B = {5, 7};
    printf("Can we change (one character at a time) characters stored in 'YOUR_ANSWER' variable after declaration? %s\n", YOUR_ANSWER);
    printf("Can we change (one character at a time) characters stored in 'YES' variable after declaration? %s\n", YOUR_ANSWER);
    printf("Can we change (one character at a time) characters stored in 'NO' variable after declaration? %s\n", YOUR_ANSWER);
    printf("Can we change (one character at a time) characters stored in 'argv[0]' variable after declaration? %s\n", YOUR_ANSWER);
    printf("Can we change (whole string at once) string stored in 'argv[0]' variable after declaration? %s\n", YOUR_ANSWER);
    printf("Can we change integer stored in 'i' variable after declaration? %s\n", YOUR_ANSWER);
    printf("Can we change integer stored in 'j' variable after declaration? %s\n", YOUR_ANSWER);
    printf("Can we change integer stored in 'A.x' variable after declaration? %s\n", YOUR_ANSWER);
    printf("Can we change integer stored in 'A.y' variable after declaration? %s\n", YOUR_ANSWER);
    printf("Can we change integer stored in 'B.x' variable after declaration? %s\n", YOUR_ANSWER);
    printf("Can we change integer stored in 'B.y' variable after declaration? %s\n", YOUR_ANSWER);
    return 0;
}
