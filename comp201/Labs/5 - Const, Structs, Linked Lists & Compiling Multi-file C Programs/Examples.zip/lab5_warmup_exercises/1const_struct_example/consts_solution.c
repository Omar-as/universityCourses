#include<stdio.h>

const char* YOUR_ANSWER = "YOUR ANSWER";
char* YES = "YES";
char NO[10] = "NO";
int j = 3;

struct coordinates2d{
    int x;
    const int y;
};

int main(int argc, char const *argv[])
{   
    // YOU CAN COMPARE YOUR ANSWERS WITH THE SOLUTIONS 
    const int i = 10;
    struct coordinates2d A = {i, j};
    const struct coordinates2d B = {5, 7};
    printf("Can we change (one character at a time) characters stored in 'YOUR_ANSWER' variable after declaration? %s\n", NO); // because of "const" in line 3
    printf("Can we change (one character at a time) characters stored in 'YES' variable after declaration? %s\n", NO); // because it is stored in DATA SEGMENT  
    printf("Can we change (one character at a time) characters stored in 'NO' variable after declaration? %s\n", YES);
    printf("Can we change (one character at a time) characters stored in 'argv' variable after declaration? %s\n", NO); // because of "const" in line 13
    printf("Can we change (one character at a time) characters stored in 'argv' variable after declaration? %s\n", YES);
    printf("Can we change integer stored in 'i' variable after declaration? %s\n", NO); // because of "const" in line 17
    printf("Can we change integer stored in 'j' variable after declaration? %s\n", YES);
    printf("Can we change integer stored in 'A.x' variable after declaration? %s\n", YES);
    printf("Can we change integer stored in 'A.y' variable after declaration? %s\n", NO); // because of "const" in line 10
    printf("Can we change integer stored in 'B.x' variable after declaration? %s\n", NO); // because of "const" in line 19
    printf("Can we change integer stored in 'B.y' variable after declaration? %s\n", NO); // because of "const" in line 19
    return 0;
}
