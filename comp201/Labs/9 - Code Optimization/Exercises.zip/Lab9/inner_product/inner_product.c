#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define SIZE 1000000

float inner_product(float udata[], float vdata[]){
    clock_t start,end;
    start = clock();

    int i;
    float sum = 0.0;

    for (i = 0; i < SIZE; i++) {
        sum = sum + udata[i] * vdata[i];
    }
    end = clock();
    double elapsed = (double) 1000.0*(end-start)/CLOCKS_PER_SEC;

    printf("Elapsed time with inner_product (ms): %f\n", elapsed);
    return sum;

}


int main()
{
    float u[SIZE];
    float v[SIZE];

    /*Generate random numbers */
    int i;
    for(i=0; i<SIZE; i++){
        u[i] = rand() % 1000 / 32.0;
        v[i] = rand() % 1000 / 32.0;
    }
    printf("\tResult: %f\n", inner_product(u, v));

    return 0;
}





