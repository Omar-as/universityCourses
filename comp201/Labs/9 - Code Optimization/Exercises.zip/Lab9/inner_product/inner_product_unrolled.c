#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define SIZE 1000000

float inner_product(float udata[], float vdata[]){
    
    int i;
    int limit = SIZE-5;  /* Exit loop when there are less than 6 elements. */
    clock_t start,end;
    float sum = 0.0;
    float sum0 = 0.0;
    float sum1 = 0.0;
    float sum2 = 0.0;
    float sum3 = 0.0;
    float sum4 = 0.0;
    float sum5 = 0.0;
    start = clock();
    
    // Unroll 5x
    for (i = 0; i < limit; i+=6) {
        sum0 = sum0 + udata[i] * vdata[i];
        sum1 = sum1 + udata[i+1] * vdata[i+1];
        sum2 = sum2 + udata[i+2] * vdata[i+2];
        sum3 = sum3 + udata[i+3] * vdata[i+3];
        sum4 = sum4 + udata[i+4] * vdata[i+4];
        sum5 = sum5 + udata[i+5] * vdata[i+5];
    }
    
    // Product of the remaining elements
    printf("%d, %d\n", i, SIZE);
    for (; i < SIZE; i++) {
        sum = sum + udata[i] * vdata[i];
    
    }
    printf("%d\n", i);
    end = clock();
    double elapsed = (double) 1000.0*(end-start)/CLOCKS_PER_SEC;

    printf("Elapsed time with inner_product (Loop Unrolled) (ms): %f\n", elapsed);

    return sum0 + sum1 + sum2 + sum3  + sum4 + sum5;
}


int main()
{
    float u[SIZE];
    float v[SIZE];
    
    int i;
    for(i=0; i<SIZE; i++){
        u[i] = rand() % 1000 / 32.0;
        v[i] = rand() % 1000 / 32.0;
    }
    printf("\tResult: %f\n", inner_product(u, v));
    
    return 0;
}
