#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define  DATA_LEN 100000


void selectionSort(int array[], int size) {

 // loop to access each array element
 int i,j,min,temp;
 
 for(i=0;i<size;i++){
     min = i;
     for(j=i+1;j<size;j++)
     {
       if(array[min]>array[j])
       {
         min = j;
       }
     }
     temp       = array[min];
     array[min] = array[i];
     array[i]   = temp;
  }
  
}


void bubbleSort(int array[], int size) {

  // loop to access each array element
  int step, i, temp;
  
  for (step = 0; step < size - 1; ++step) {
      
    // loop to compare array elements
    for (i = 0; i < size - step - 1; ++i) {
      
      // compare two adjacent elements
      // change > to < to sort in descending order
      if (array[i] > array[i + 1]) {
        
        // swapping occurs if elements
        // are not in the intended order
        temp         = array[i];
        array[i]     = array[i + 1];
        array[i + 1] = temp;
      }
    }
  }
}

void opt_bubbleSort(int array[], int size) {

  // loop to access each array element
  int step, i;
  for (step = 0; step < size - 1; ++step) {
    
    // check if swapping occurs  
    int swapped = 0;
    
    // loop to compare array elements
    for (i = 0; i < size - step - 1; ++i) {
      
      // compare two array elements
      // change > to < to sort in descending order
      if (array[i] > array[i + 1]) {
        
        // swapping occurs if elements
        // are not in the intended order
        int temp = array[i];
        array[i] = array[i + 1];
        array[i + 1] = temp;
        
        swapped = 1;
      }
    }
    
    // no swapping means the array is already sorted
    // so no need for further comparison
    if (swapped == 0) {
      break;
    }
    
  }
}


int main()
{

   int data[DATA_LEN],i,j,min,temp;
   
   for(i=0;i<DATA_LEN;i++)
      data[i]=rand()%DATA_LEN;


   //The Normal bubble Sort
   clock_t start,end;
   start        = clock();
   
   bubbleSort(data, DATA_LEN);
   
   end          = clock();
   double extime= (double) (end-start)/CLOCKS_PER_SEC;
   printf("Execution time for the normal bubble sort is %f seconds\n ", extime);


   for(i=0;i<DATA_LEN;i++)
      data[i]=rand()%DATA_LEN;


   //The selection Sort
   start    = clock();
   
   selectionSort(data, DATA_LEN);
   
   end      = clock();
   extime   = (double) (end-start)/CLOCKS_PER_SEC;
   printf("Execution time for the selection sort is %f seconds\n", extime);
   
      for(i=0;i<DATA_LEN;i++)
      data[i]=rand()%DATA_LEN;


   //The optimized bubble Sort
   start    = clock();
   
   opt_bubbleSort(data, DATA_LEN);
   
   end      = clock();
   extime   = (double) (end-start)/CLOCKS_PER_SEC;
   printf("Execution time for the Optimized bubble sort is %f seconds\n", extime);

}
