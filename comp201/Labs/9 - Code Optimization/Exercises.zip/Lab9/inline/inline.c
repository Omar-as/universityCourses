#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define foo(a, b) (((a)-(b)) * ((b)+1))  

int main(){
	int i; 
	float num1;
	float num2;
	clock_t start = clock();
	float result;
	for(i=0; i<1e8; i++){
		num1 = (float)(rand() % 100);
		num2 = (float)(rand() % 100);
		result = foo(num1, num2);
		//printf("Foo(%f, %f) = %f\n", num1, num2, foo(num1, num2));
	}
	clock_t end = clock();
	double elapsed = (double) 1000.0*(end-start)/CLOCKS_PER_SEC;

	printf("Elapsed time with inline (ms): %f\n", elapsed);

}
