#include <stdio.h>
#include <stdlib.h>
#include <time.h>
float foo(float a, float b){
	a = a - b;
	b = b + 1;
	a = a * b;
	return a;
}

int main(){
	int i;
	clock_t start = clock();
	for(i=0; i<1e8; i++){
		float num1 = (float) (rand() % 100);
		float num2 = (float) (rand() % 100);
		float result = foo(num1, num2);
		//printf("Foo(%f, %f) = %f\n", num1, num2, foo(num1, num2));
	}
        clock_t end = clock();
        double elapsed = (double) 1000.0*(end-start)/CLOCKS_PER_SEC;

        printf("Elapsed time with function (ms): %f\n", elapsed);

}
