#include <stdio.h>
#include <string.h>

char* secret_pin="comp201";

void transfer_money() {
	printf("$1000 was transferred to your account.\n");
}

void ask_pin(){
}

void check_password() {	
	char check_pin[10];
	printf("Enter pin: ");
	scanf("%s", check_pin);

	if(!strcmp(check_pin,"comp201")){
		printf("Correct Pin!\n");
		transfer_money();
	}else{
		printf("Wrong Pin!\n");
	}
}

int main() {
	check_password();
	return 0;
}
