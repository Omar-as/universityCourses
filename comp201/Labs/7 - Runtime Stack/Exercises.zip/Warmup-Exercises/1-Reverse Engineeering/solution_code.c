
int foo3(int a, int b, int c) {
	return a + b - c;
}

int foo1(int a, int b, int c, int d){
	return foo3(a, b*c, d);
}

int foo(){
	int a = 1;
	int b = 2;
	int c = 3;
	int d = 4;
	return foo1(a, b, c, d);
}
