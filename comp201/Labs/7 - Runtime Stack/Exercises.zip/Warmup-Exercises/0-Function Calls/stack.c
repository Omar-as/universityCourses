int sum(int a, int b){
	int c = 0;
	c = a + b;
	return c;
}

int square(int s){
	int sq = s * s;
	return sq;
}

int sos(int n1, int n2){
	int sq1 = square(n1);
	int sq2 = square(n2);

	return sum(sq1, sq2);
}

int main(){
	int num1 = 3;
	int num2 = 5;
	printf("num 1 = %d, num2 = %d\n", num1, num2);

	printf("SoS = %d\n", sos(num1, num2));
	return 0;
}
