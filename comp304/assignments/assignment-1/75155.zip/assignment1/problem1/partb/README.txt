To compile the code:
    "gcc p1b.c -o main"
To Run the code:
    "./main | ps -l"

The zombie process would show up as Z
