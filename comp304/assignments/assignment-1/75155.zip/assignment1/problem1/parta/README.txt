To compile the code use:
    "gcc p1a.c -o main"
Then to run the code:
    "./main n"
    n = the number of children you would like to fork.
