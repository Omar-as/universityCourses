To run the code:
    "gcc p1.c -o main"
To run the code:
    "./main n command"
    
    n = number of children forked
    command = command you want the children to run

Example of running:
    "./main 5 ls -la"

