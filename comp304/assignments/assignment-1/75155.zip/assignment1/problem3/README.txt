To compile the code:
    "gcc p3.c -o main"
To run the code:
    "shuf -i j-k | ./main x n"

    j = starting number
    k = end number. No more than 1000
    x = the number we want to find the index for
    n = the number of children forked you want

To check whether the answer is correct:
    uncomment lines 42-45
This will print out the array with all the numbers and their indeces.
