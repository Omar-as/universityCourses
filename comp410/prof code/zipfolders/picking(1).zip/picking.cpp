//
//  Pick one of the two triangles
//
#include "Angel.h"

typedef vec4  point4;
const int NumVertices = 6;

// Vertices of two triangles
point4 vertices[NumVertices] = {
    point4( -0.6, -0.6,  0.2, 1.0 ),
    point4( -0.5,  0.5,  0.2, 1.0 ),
    point4(  0.5,  0.5,  0.2, 1.0 ),
    point4( 0.6, 0.6,  -0.2, 1.0 ),
    point4( 0.5, -0.5,  -0.2, 1.0 ),
    point4(  -0.5,  -0.1,  -0.2, 1.0 )
};

// Model-view and projection matrices and color uniform location
GLuint  ModelView, Projection;
GLuint Color;

//  initialization
void init()
{
    // Create a vertex array object
    GLuint vao;
    glGenVertexArrays( 1, &vao );
    glBindVertexArray( vao );

    // Create and initialize a buffer object
    GLuint buffer;
    glGenBuffers( 1, &buffer );
    glBindBuffer( GL_ARRAY_BUFFER, buffer );
    glBufferData( GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW );
        
    // Load shaders and use the resulting shader program
    GLuint program = InitShader( "vshader.glsl", "fshader.glsl" );
    // Set current program object
    glUseProgram( program ); // Actually you don't need this because it's already invoked in InitShader
    
    // set up vertex arrays
    GLuint vPosition = glGetAttribLocation( program, "vPosition" );
    glEnableVertexAttribArray( vPosition );
    glVertexAttribPointer( vPosition, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0) );
    
    // Retrieve transformation uniform variable locations
    ModelView = glGetUniformLocation( program, "ModelView" );
    Projection = glGetUniformLocation( program, "Projection" );

    // Set projection matrix
    mat4 projection;
    projection = Ortho(-1.0, 1.0, -1.0, 1.0, -1.0, 1.0); 
    glUniformMatrix4fv( Projection, 1, GL_TRUE, projection );
    
    mat4  model_view =  identity();
    glUniformMatrix4fv( ModelView, 1, GL_TRUE, model_view );
    
    Color = glGetUniformLocation( program, "color" );

    // Enable hiddden surface removal
    glEnable( GL_DEPTH_TEST );
    
    // Set state variable "clear color" to clear the buffer
    glClearColor( 1.0, 1.0, 1.0, 1.0 );
   }

//----------------------------------------------------------------------------

void display( void )
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
    glUniform4f( Color, 1.0, 0.0, 0.0, 1.0 );
    glDrawArrays( GL_TRIANGLES, 0, 3 ); //Draw first triangle
    glUniform4f( Color, 0.0, 0.0, 0.0, 1.0 );
    glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
    glDrawArrays( GL_TRIANGLES, 0, 3 ); //Draw edges of the first triangle
  
    glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
    glUniform4f( Color, 1.0, 0.0, 0.0, 1.0 );
    glDrawArrays(GL_TRIANGLES, 3, 3); //Draw second triangle
    glUniform4f( Color, 0.0, 0.0, 0.0, 1.0 );
    glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
    glDrawArrays(GL_TRIANGLES, 3, 3); //Draw edges of the second triangle
    glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
}

void mouse_button_callback(GLFWwindow* window, int button, int action, int mods)
{
    if ( action == GLFW_PRESS && button == GLFW_MOUSE_BUTTON_LEFT) {
        //glDrawBuffer(GL_BACK); //back buffer is default thus no need
        
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        
        //Render triangles with different id colors to back buffer
            
        glUniform4f( Color, 0.0, 1.0, 0.0, 1.0 );
        glDrawArrays( GL_TRIANGLES, 0, 3 );
        
       glUniform4f( Color, 0.0, 0.0, 1.0, 1.0 );
       glDrawArrays(GL_TRIANGLES, 3, 3);
        
        glFlush(); //forces all drawing commands to be sent to the graphics card and executed immediately.
        glFinish();
        
        double x, y;
        glfwGetCursorPos(window, &x, &y);

        int fb_width, fb_height;
        glfwGetFramebufferSize(window, &fb_width, &fb_height);
        
        int win_width, win_height;
        glfwGetWindowSize(window, &win_width, &win_height);
        
        //Have to differentiate between window and frame buffer sizes
        x*=(fb_width/win_width);
        y*=(fb_height/win_height);
        
        y = fb_height - y;
                
        
        //glReadPixels reads from frame buffer, hence use frame buffer size
        unsigned char pixel[4];
        glReadPixels(x, y, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, pixel);
        if (pixel[0]==0 && pixel[1]==255 && pixel[2]==0) std::cout << "First triangle"<<std::endl;
        else if (pixel[0]==0 && pixel[1]==0 && pixel[2]==255) std::cout << "Second triangle"<<std::endl;
        else std::cout << "None"<<std::endl;
        
        std::cout << "R: " << (int)pixel[0] << std::endl;
        std::cout << "G: " << (int)pixel[1] << std::endl;
        std::cout << "B: " << (int)pixel[2] << std::endl;
        std::cout << std::endl;
        
        //glfwSwapBuffers(window); //you can enable (and disable the other) this to display the triangles with their hidden id colors
    }
}
//----------------------------------------------------------------------------

int main( int argc, char **argv )
{
    if (!glfwInit())
            exit(EXIT_FAILURE);
    
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 2);
    glfwWindowHint(GLFW_OPENGL_PROFILE,GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
    glfwWindowHint(GLFW_RESIZABLE, GL_TRUE);
    
    GLFWwindow* window = glfwCreateWindow(512, 512, "Picking", NULL, NULL);
    glfwMakeContextCurrent(window);
    
    if (!window)
        {
            glfwTerminate();
            exit(EXIT_FAILURE);
        }

    glfwSetMouseButtonCallback(window, mouse_button_callback);
    
    init();

    while (!glfwWindowShouldClose(window))
    {
        display();
        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    
    glfwDestroyWindow(window);
    glfwTerminate();
    exit(EXIT_SUCCESS);
}
