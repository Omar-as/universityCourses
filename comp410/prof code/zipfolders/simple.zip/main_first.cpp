//
//  main.cpp
//  simple
//

#include "Angel.h" // includes also glwf3.h and gl3.h

const GLuint  NumVertices = 6;
GLuint program;
//---------------------------------------------------------------------
// init
//

void
init(void)
{
    // Set vertex array object(s)
    GLuint vao;
    glGenVertexArrays( 1, &vao );
    glBindVertexArray( vao );
    
    GLfloat  vertices[NumVertices][3] = {
        { -0.5, -0.5, 0.0 },
        { -0.5,  0.5, 0.0 },
        {  0.5,  0.5, 0.0 },
        {  0.5, -0.5, 0.0 },
        { -0.5, -0.5, 0.0 },
        {  0.5,  0.5, 0.0 }
    };
    
    // Set vertex buffer object(s) and send data to GPU
    GLuint buffer;
    glGenBuffers( 1, &buffer );
    glBindBuffer( GL_ARRAY_BUFFER, buffer );
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
     
    // Load shaders and use the resulting shader program
    program = InitShader("vshader_simple.glsl","fshader_simple.glsl" );
    glUseProgram( program );
    
    // Associate attribute variable(s) in the shader with the vertex attribute data in the buffer
    GLuint loc = glGetAttribLocation( program, "vPosition" );
    glEnableVertexAttribArray( loc );
    glVertexAttribPointer(loc, 3, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));
}

//---------------------------------------------------------------------
//
// display
//

void
display(void)
{
    glClear(GL_COLOR_BUFFER_BIT);
    glDrawArrays(GL_TRIANGLES, 0, NumVertices);
    glFlush();
}


//---------------------------------------------------------------------
//
// main
//

int
main()
{
   if (!glfwInit())
           exit(EXIT_FAILURE);
    
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 2);
    glfwWindowHint(GLFW_OPENGL_PROFILE,GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
    glfwWindowHint(GLFW_RESIZABLE, GL_FALSE);

    GLFWwindow* window = glfwCreateWindow(500, 500, "Simple", NULL, NULL);
    glfwMakeContextCurrent(window);
    
    if (!window)
    {
            glfwTerminate();
            exit(EXIT_FAILURE);
    }

    init();

    while (!glfwWindowShouldClose(window))
    {
        display();
        glfwSwapBuffers(window);
        glfwPollEvents(); // glfwWaitEvents
    }
    
    glfwDestroyWindow(window);
    glfwTerminate();
    exit(EXIT_SUCCESS);
    
}
