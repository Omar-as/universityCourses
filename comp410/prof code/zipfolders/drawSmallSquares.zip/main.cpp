#include "Angel.h"

const int NumVertices = 6;
const int OriginX = -1; //The small square is initiall positioned at (-1,-1)
const int OriginY = -1;
const float size = 0.05;

GLuint Cursor, RandomColor, WindowSize;

void init(GLFWwindow* window){
    //vertices of the small square
    vec2 vertices[NumVertices] = {
        vec2(OriginX - size, OriginY - size),
        vec2(OriginX - size, OriginY + size),
        vec2(OriginX + size, OriginY + size),
        vec2(OriginX + size, OriginY - size),
        vec2(OriginX - size, OriginY - size),
        vec2(OriginX + size, OriginY + size)
    };
    
    GLuint vao;
    glGenVertexArrays(1, &vao);
    glBindVertexArray(vao);
    
    GLuint buffer;
    glGenBuffers(1, &buffer);
    glBindBuffer(GL_ARRAY_BUFFER, buffer);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
    
    // Load shaders and use the resulting shader program
    GLuint program = InitShader("vshader_small.glsl", "fshader_small.glsl");
    glUseProgram(program);
    
    GLuint loc = glGetAttribLocation(program, "vPosition");
    glEnableVertexAttribArray(loc);
    glVertexAttribPointer(loc, 2, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));
    
    Cursor = glGetUniformLocation(program, "cursor");
    RandomColor = glGetUniformLocation(program, "randomColor");
    WindowSize = glGetUniformLocation(program, "windowSize");
    
    glClearColor(1.0, 1.0, 1.0, 1.0);
    glClear(GL_COLOR_BUFFER_BIT);
    glfwSwapBuffers(window);
    glClear(GL_COLOR_BUFFER_BIT);
    //glfwSwapBuffers(window);
}

void drawSquare(GLFWwindow* window, double xpos, double ypos) {
    glUniform2f(Cursor, (float)xpos, (float)ypos);
    glUniform3f(RandomColor, ((float)rand()) / RAND_MAX, ((float)rand()) / RAND_MAX, ((float)rand()) / RAND_MAX);
    
    int width, height;
    glfwGetWindowSize(window, &width, &height);
    glUniform2f(WindowSize, (float)width, (float)height);
    
    glClear(GL_COLOR_BUFFER_BIT);
    glDrawArrays(GL_TRIANGLES, 0, NumVertices);
    glfwSwapBuffers(window);
    glDrawArrays(GL_TRIANGLES, 0, NumVertices);
    glfwSwapBuffers(window);
    
}

void mouse_button_callback(GLFWwindow* window, int button, int action, int mods)
{
    if (button == GLFW_MOUSE_BUTTON_RIGHT && action == GLFW_PRESS)
        exit(0);
    
    if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_PRESS) {
        double xpos, ypos;
        glfwGetCursorPos(window, &xpos, &ypos);
        drawSquare(window, xpos, ypos);
    }
}

//could use this to draw squares (or anything else) continuously while mouse is moved
void mouse_cursor_callback(GLFWwindow* window, double xpos, double ypos)
{
        drawSquare(window, xpos, ypos);
}

int main(void) {
    GLFWwindow* window;
    
    /* Initialize the library */
    if (!glfwInit())
        return -1;
    
    
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 2);
    glfwWindowHint(GLFW_OPENGL_PROFILE,GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
    //glfwWindowHint(GLFW_RESIZABLE, GL_FALSE);
    
    /* Create a windowed mode window and its OpenGL context */
    window = glfwCreateWindow(500, 500, "Draw Small Squares", NULL, NULL);
    if (!window) {
        glfwTerminate();
        return -1;
    }
    
    /* Make the window's context current */
    glfwMakeContextCurrent(window);
    
    init(window);
    
    /* Set the mouse button callback */
    glfwSetMouseButtonCallback(window, mouse_button_callback);
    //glfwSetCursorPosCallback(window, mouse_cursor_callback);
    
    /* Loop until the user closes the window */
    while (!glfwWindowShouldClose(window)) {
        /* Poll for and process events */
        glfwPollEvents();
    }
    
    glfwTerminate();
    return 0;
}

