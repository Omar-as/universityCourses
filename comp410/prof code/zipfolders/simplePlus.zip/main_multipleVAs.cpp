//
//  main.cpp
//  simple with multiple VAOs
//
#include "Angel.h"

const GLuint  NumVertices = 6;
GLuint vao[2];

//---------------------------------------------------------------------
//
// init
//

void
init(void)
{
    
    GLfloat  vertices[NumVertices][3] = {
        { -0.5, -0.5, 0.0 },
        { -0.5,  0.5, 0.0 },
        {  0.5,  0.5, 0.0 },
        {  0.5, -0.5, 0.0 },
        { -0.5, -0.5, 0.0 },
        {  0.5,  0.5, 0.0 }
    };
    
    GLfloat  vertices2[NumVertices][3] = {
        { -0.6, -0.6, 0.0 },
        { -0.6,  0.4, 0.0 },
        {  0.4,  0.4, 0.0 },
        {  0.4, -0.6, 0.0 },
        { -0.6, -0.6, 0.0 },
        {  0.4,  0.4, 0.0 }
    };
    
    // Load shaders and use the resulting shader program
    GLuint program = InitShader( "vshader_simple.glsl", "fshader_simple.glsl" );
    glUseProgram( program );
    
    // Generate vertex array object names
    glGenVertexArrays( 2, vao );
    
    // Set the first vertex array
    glBindVertexArray( vao[0] ); //Set the first vertex array

    // Create and bind vertex buffer object
    GLuint buffer;
    glGenBuffers( 1, &buffer );
    glBindBuffer( GL_ARRAY_BUFFER, buffer ); // this buffer is attached to vao[0]
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
    
    GLuint loc = glGetAttribLocation( program, "vPosition" );
    glEnableVertexAttribArray( loc ); // set to use current buffer hen passing attribute data to shader
    glVertexAttribPointer(loc, 3, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));
    
    // Set the second vertex array with shifted vertex coordinates
    glBindVertexArray( vao[1] );
    
    // Create and bind a second vertex buffer object
    GLuint buffer2;
    glGenBuffers( 1, &buffer2 );
    glBindBuffer( GL_ARRAY_BUFFER, buffer2 ); // this buffer is attached to vao[1]
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices2), vertices2, GL_STATIC_DRAW);
    
    glEnableVertexAttribArray( loc ); // set to use current buffer when passing attribute data to shader
    glVertexAttribPointer(loc, 3, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));
    
}

//---------------------------------------------------------------------
//
// display
//

void
display(void)
{
    
    glClear(GL_COLOR_BUFFER_BIT);
    
    glBindVertexArray( vao[0] ); // bind first vertex array
    glDrawArrays(GL_TRIANGLES, 0, NumVertices);
    
    glBindVertexArray( vao[1] ); // bind second vertex array
    glDrawArrays(GL_TRIANGLES, 0, NumVertices);
    
    glFlush();
}


//---------------------------------------------------------------------
//
// main
//

int
main()
{
    if (!glfwInit())
            exit(EXIT_FAILURE);
    
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 2);
    glfwWindowHint(GLFW_OPENGL_PROFILE,GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
    //glfwWindowHint(GLFW_RESIZABLE, GL_TRUE);
    
    GLFWwindow* window = glfwCreateWindow(500, 500, "Simple", NULL, NULL);
    glfwMakeContextCurrent(window);
    
    if (!window)
        {
            glfwTerminate();
            exit(EXIT_FAILURE);
        }
    
    init();

    while (!glfwWindowShouldClose(window))
    {
        display();
        glfwSwapBuffers(window);
        glfwPollEvents(); // glfwWaitEvents
    }
    
    glfwDestroyWindow(window);
    
    glfwTerminate();
    exit(EXIT_SUCCESS);
    
}




