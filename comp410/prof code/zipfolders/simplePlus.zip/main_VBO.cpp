//
//  main.cpp
//  simple (with BufferSubdata)
//

#include "Angel.h"

const GLuint  NumVertices = 6;
GLuint loc;
unsigned int sizeOfVertexArray;

//---------------------------------------------------------------------
//
// init
//

void
init(void)
{
    // Set vertex array object(s)
    GLuint vao;
    glGenVertexArrays( 1, &vao );
    glBindVertexArray( vao );
    
    GLfloat  vertices[NumVertices][3] = {
        { -0.5, -0.5, 0.0 },
        { -0.5,  0.5, 0.0 },
        {  0.5,  0.5, 0.0 },
        {  0.5, -0.5, 0.0 },
        { -0.5, -0.5, 0.0 },
        {  0.5,  0.5, 0.0 }
    };
    
    GLfloat  vertices2[NumVertices][3] = {
        { -0.2, -0.2, 0.0 },
        { -0.2,  0.2, 0.0 },
        {  0.2,  0.2, 0.0 },
        {  0.2, -0.2, 0.0 },
        { -0.2, -0.2, 0.0 },
        {  0.2,  0.2, 0.0 }
    };

    sizeOfVertexArray = sizeof(vertices);

    // Load shaders and use the resulting shader program
    GLuint program = InitShader("vshader_simple.glsl","fshader_simple.glsl" );
    glUseProgram( program );
    
    // Create a VBO and store the data for both vertices and vertices2 in the same buffer
    GLuint buffer;
    glGenBuffers( 1, &buffer );
    glBindBuffer( GL_ARRAY_BUFFER, buffer );
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices)+sizeof(vertices2), NULL, GL_STATIC_DRAW);
    
    // Store the data for vertices in the first part of the buffer and the vertices2 data in the second part.
    glBufferSubData( GL_ARRAY_BUFFER, 0, sizeof(vertices), vertices );
    glBufferSubData( GL_ARRAY_BUFFER, sizeof(vertices), sizeof(vertices2), vertices2 );
    
    loc = glGetAttribLocation( program, "vPosition" );
    glEnableVertexAttribArray( loc );
    glVertexAttribPointer(loc, 3, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(sizeOfVertexArray));
    
}

//---------------------------------------------------------------------
//
// display
//

void
display(void)
{
    glClear(GL_COLOR_BUFFER_BIT);
    glDrawArrays(GL_TRIANGLES, 0, NumVertices);
    glFlush();
}

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    switch( key ) {
        case GLFW_KEY_ESCAPE: case GLFW_KEY_Q:
            exit( EXIT_SUCCESS );
            break;
        case GLFW_KEY_2:
            glVertexAttribPointer(loc, 3, GL_FLOAT, GL_FALSE, 0,BUFFER_OFFSET(sizeOfVertexArray));
            // can switch between diffeent parts of the buffer by modifying BUFFER_OFFSET(sizeOfVertexArray)
            break;
        case GLFW_KEY_1:
            glVertexAttribPointer(loc, 3, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));
            break;
    }
}


//---------------------------------------------------------------------
//
// main
//

int
main()
{
    if (!glfwInit())
            exit(EXIT_FAILURE);
    
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 2);
    glfwWindowHint(GLFW_OPENGL_PROFILE,GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
    //glfwWindowHint(GLFW_RESIZABLE, GL_TRUE);
    
    GLFWwindow* window = glfwCreateWindow(500, 500, "Simple", NULL, NULL);
    glfwMakeContextCurrent(window);
    
    if (!window)
        {
            glfwTerminate();
            exit(EXIT_FAILURE);
        }

    glfwSetKeyCallback(window, key_callback);
    
    init();

    while (!glfwWindowShouldClose(window))
    {
        display();
        glfwSwapBuffers(window);
        glfwWaitEvents(); // glfwWaitEvents
    }
    
    glfwDestroyWindow(window);
    
    glfwTerminate();
    exit(EXIT_SUCCESS);
    
}




