//
//  main.cpp
//  simple with Projection and multiple program objects
//

#include "Angel.h"

const GLuint  NumVertices = 6;
GLuint program, program2;
//---------------------------------------------------------------------
//
// init
//

void
init(void)
{
    // Set vertex array object(s)
    GLuint vao[1];
    glGenVertexArrays( 1, vao );
    glBindVertexArray( vao[0] );
    
    GLfloat  vertices[NumVertices][3] = {
        { -0.5, -0.5, 0.0 },
        { -0.5,  0.5, 0.0 },
        {  0.5,  0.5, 0.0 },
        {  0.5, -0.5, 0.0 },
        { -0.5, -0.5, 0.0 },
        {  0.5,  0.5, 0.0 }
    };
    
    // Load shaders and use the resulting shader program
    program = InitShader("vshader_simple.glsl","fshader_simple.glsl" );
    
    // Set vertex buffer object(s)
    GLuint buffer;
    glGenBuffers( 1, &buffer );
    glBindBuffer( GL_ARRAY_BUFFER, buffer );
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
     
    // Associate attribute variable(s) in the shader with the vertex attribute data in the buffer
    
    GLuint loc = glGetAttribLocation( program, "vPosition" );
    glEnableVertexAttribArray( loc );
    glVertexAttribPointer(loc, 2, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));
    
    glUseProgram( program );
    
    // Repeat the same procedure for another "program" object

    program2 = InitShader( "vshader_simple2.glsl", "fshader_simple.glsl" );
    
    GLuint buffer2;
    glGenBuffers( 1, &buffer2 );
    glBindBuffer( GL_ARRAY_BUFFER, buffer2 );
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
    
    GLuint loc2 = glGetAttribLocation( program2, "vPosition" );
    glEnableVertexAttribArray( loc2 );
    glVertexAttribPointer(loc2, 3, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));
    
    mat4 projection = Ortho(-2.0, 2.0, -2.0, 2.0,-2.0, 2.0); // use a different view volume for the second program object
    
    loc2 = glGetUniformLocation( program2, "Projection" );
    glUniformMatrix4fv( loc2, 1, GL_TRUE, projection );

    
    glUseProgram( program2 );
}

//---------------------------------------------------------------------
//
// display
//

void
display(void)
{
    
    glClear(GL_COLOR_BUFFER_BIT);
    glDrawArrays(GL_TRIANGLES, 0, NumVertices);
    glFlush();
}


static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
  
    switch( key ) {
        case GLFW_KEY_Z: case GLFW_KEY_Q:
            exit( EXIT_SUCCESS );
            break;
        case GLFW_KEY_2:
            glUseProgram( program2 ); // can switch between two program objects
            break;
        case GLFW_KEY_1:
            glUseProgram( program ); // can switch between two program objects
            break;
    }
}


//---------------------------------------------------------------------
//
// main
//

int
main()
{
    if (!glfwInit())
            exit(EXIT_FAILURE);
    
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 2);
    glfwWindowHint(GLFW_OPENGL_PROFILE,GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
    glfwWindowHint(GLFW_RESIZABLE, GL_TRUE);
    
    GLFWwindow* window = glfwCreateWindow(500, 500, "Simple", NULL, NULL);
    glfwMakeContextCurrent(window);
    
    if (!window)
        {
            glfwTerminate();
            exit(EXIT_FAILURE);
        }

    glfwSetKeyCallback(window, key_callback);
    
    init();

    while (!glfwWindowShouldClose(window))
    {
        display();
        glfwSwapBuffers(window);
        glfwPollEvents(); // glfwWaitEvents
    }
    
    glfwDestroyWindow(window);
    
    glfwTerminate();
    exit(EXIT_SUCCESS);
    
}




